import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import AppLayout from './components/AppLayout';
import Login from './pages/auth/Login';
import Dashboard from './pages/dashboard/Dashboard';
import DocumentsList from './pages/documents/DocumentsList';
import WorkspacePage from './components/workspace/WorkspacePage';
import AnalyticsPage from './pages/analytics/AnalyticsPage';
import EditorPage from './pages/editor/EditorPage';
import SettingsPage from './pages/settings/SettingsPage';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<AppLayout><Dashboard /></AppLayout>} />
        <Route path="/documents" element={<AppLayout><DocumentsList /></AppLayout>} />
        <Route path="/workspace" element={<AppLayout><WorkspacePage /></AppLayout>} />
        <Route path="/analytics" element={<AppLayout><AnalyticsPage /></AppLayout>} />
        <Route path="/editor/:docId" element={<AppLayout><EditorPage /></AppLayout>} />
        <Route path="/settings" element={<AppLayout><SettingsPage /></AppLayout>} />
      </Routes>
    </Router>
  );
}