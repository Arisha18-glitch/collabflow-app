import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDocStore } from '../../store/useDocStore';
import { ExternalLink, ShieldCheck, UserPlus, UserMinus, X, Users, Mail, Check } from 'lucide-react';

const VALID_ROLES = ['Owner', 'Editor', 'Viewer'];

export default function WorkspacePage() {
    const navigate = useNavigate();
    const {
        members, docs, stats, activeDocId,
        addMember, removeMember, setActiveDoc, currentUserRole
    } = useDocStore();

    const activeDoc = docs.find(d => d.id === activeDocId) ?? docs[0];

    const [showInvite,  setShowInvite]  = useState(false);
    const [inviteName,  setInviteName]  = useState('');
    const [inviteEmail, setInviteEmail] = useState('');
    const [inviteRole,  setInviteRole]  = useState('Editor');
    const [inviteError, setInviteError] = useState('');
    const [inviteSent,  setInviteSent]  = useState('');   // holds email that was just invited

    const handleInvite = () => {
        const name  = inviteName.trim();
        const email = inviteEmail.trim();
        if (!name)  { setInviteError('Name is required'); return; }
        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            setInviteError('Enter a valid email address'); return;
        }
        if (!VALID_ROLES.includes(inviteRole)) { setInviteError('Select a valid role'); return; }
        addMember(name, inviteRole);
        // Simulate sending invite email
        const sentTo = email || `${name.toLowerCase().replace(/\s+/g, '.')}@example.com`;
        setInviteSent(sentTo);
        setTimeout(() => setInviteSent(''), 4000);
        setInviteName('');
        setInviteEmail('');
        setInviteRole('Editor');
        setInviteError('');
        setShowInvite(false);
    };

    const roleColors = { Owner: '#ec4899', Editor: '#22d3ee', Viewer: '#10b981' };
    const rolePerms  = { Owner: 'Full access', Editor: 'Create & Edit', Viewer: 'Read only' };
    const canInvite  = ['Owner'].includes(currentUserRole);

    const previewText = activeDoc
        ? activeDoc.content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().substring(0, 180)
        : '';

    return (
        <>
            {/* ── Invite Sent Toast ── */}
            {inviteSent && (
                <div style={{
                    position: 'fixed', top: 24, right: 24, zIndex: 9999,
                    background: 'rgba(34,211,238,0.12)',
                    border: '1px solid rgba(34,211,238,0.4)',
                    color: 'var(--blue)',
                    padding: '14px 20px',
                    borderRadius: 16,
                    fontWeight: 700,
                    fontSize: '0.85rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    backdropFilter: 'blur(20px)',
                    animation: 'slide-up 0.25s ease',
                    maxWidth: 340,
                    boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                }}>
                    <div style={{ width: 30, height: 30, borderRadius: 9, background: 'rgba(34,211,238,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Mail size={15} />
                    </div>
                    <div>
                        <div style={{ fontSize: '0.82rem', marginBottom: 2 }}>Invite sent!</div>
                        <div style={{ fontSize: '0.72rem', opacity: 0.75, fontWeight: 500 }}>{inviteSent}</div>
                    </div>
                    <Check size={16} style={{ marginLeft: 'auto', flexShrink: 0 }} />
                </div>
            )}
            {/* ── Invite Modal ── */}
            {showInvite && (
                <div className="modal-overlay" onClick={() => setShowInvite(false)}>
                    <div className="modal-box" onClick={e => e.stopPropagation()}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
                            <div className="modal-title">Invite Member</div>
                            <button className="icon-btn" onClick={() => setShowInvite(false)}><X size={18} /></button>
                        </div>

                        <input
                            id="invite-name"
                            className="cf-input"
                            placeholder="Full name"
                            value={inviteName}
                            onChange={e => { setInviteName(e.target.value); setInviteError(''); }}
                            autoFocus
                        />

                        <input
                            id="invite-email"
                            className="cf-input"
                            type="email"
                            placeholder="Email address to send invite"
                            value={inviteEmail}
                            onChange={e => { setInviteEmail(e.target.value); setInviteError(''); }}
                            onKeyDown={e => e.key === 'Enter' && handleInvite()}
                        />

                        <select
                            id="invite-role"
                            className="cf-select"
                            value={inviteRole}
                            onChange={e => setInviteRole(e.target.value)}
                        >
                            {VALID_ROLES.map(r => (
                                <option key={r} value={r}>{r} — {rolePerms[r]}</option>
                            ))}
                        </select>

                        {inviteError && (
                            <p style={{ color: 'var(--pink)', fontSize: '0.8rem', marginBottom: 12 }}>{inviteError}</p>
                        )}

                        <div style={{ display: 'flex', gap: 10 }}>
                            <button className="ghost-btn" onClick={() => setShowInvite(false)} style={{ flex: 1 }}>Cancel</button>
                            <button className="neon-btn" onClick={handleInvite} style={{ flex: 1 }}>Invite</button>
                        </div>
                    </div>
                </div>
            )}

            <div className="bento-grid">
                {/* ─── Col 1-2: Collaborators ─── */}
                <div className="module-box" style={{ gridColumn: 'span 2', gridRow: 'span 2' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                        <div>
                            <span className="label-text">Collaborators</span>
                            <div style={{ fontSize: '1.4rem', fontWeight: 800, letterSpacing: '-0.04em', marginTop: 2 }}>
                                {members.length} Members
                            </div>
                        </div>
                        {canInvite && (
                            <button
                                id="invite-member-btn"
                                className="ghost-btn"
                                onClick={() => setShowInvite(true)}
                                style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                            >
                                <UserPlus size={14} /> Invite
                            </button>
                        )}
                    </div>

                    <div>
                        {members.map((m) => (
                            <div key={m.id} className="member-card">
                                <div
                                    className="alphabet-badge"
                                    style={{
                                        background: m.color,
                                        boxShadow: `0 0 16px ${m.color}55`,
                                    }}
                                >
                                    {m.role[0]}
                                </div>
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{m.name}</div>
                                    <div style={{ fontSize: '0.72rem', color: m.color, opacity: 0.85, marginTop: 2 }}>
                                        {m.role} · {rolePerms[m.role]}
                                    </div>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                    <div style={{
                                        fontSize: '0.68rem',
                                        color: m.status === 'Online' ? 'var(--green)' : m.status === 'Idle' ? 'var(--blue)' : 'rgba(255,255,255,0.25)',
                                        fontWeight: 600,
                                        whiteSpace: 'nowrap',
                                    }}>
                                        ● {m.status}
                                    </div>
                                    <ShieldCheck size={13} style={{ opacity: 0.25 }} />
                                    {canInvite && m.id !== 'm1' && (
                                        <button
                                            id={`remove-member-${m.id}`}
                                            title={`Remove ${m.name}`}
                                            onClick={() => removeMember(m.id)}
                                            style={{
                                                background: 'rgba(236,72,153,0.1)',
                                                border: '1px solid rgba(236,72,153,0.25)',
                                                color: 'var(--pink)',
                                                borderRadius: 8,
                                                padding: '5px 8px',
                                                cursor: 'pointer',
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 4,
                                                fontSize: '0.7rem',
                                                fontWeight: 700,
                                                fontFamily: 'Plus Jakarta Sans, sans-serif',
                                                transition: 'all 0.2s ease',
                                                flexShrink: 0,
                                            }}
                                            onMouseEnter={e => {
                                                e.currentTarget.style.background = 'rgba(236,72,153,0.25)';
                                                e.currentTarget.style.borderColor = 'var(--pink)';
                                            }}
                                            onMouseLeave={e => {
                                                e.currentTarget.style.background = 'rgba(236,72,153,0.1)';
                                                e.currentTarget.style.borderColor = 'rgba(236,72,153,0.25)';
                                            }}
                                        >
                                            <UserMinus size={12} /> Remove
                                        </button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* ─── Col 3: Live Preview ─── */}
                <div className="module-box" style={{ gridColumn: 'span 2' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
                        <div>
                            <span className="label-text" style={{ color: 'var(--pink)' }}>Live Canvas</span>
                            <div style={{ fontWeight: 700, fontSize: '1rem', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 200 }}>
                                {activeDoc?.title ?? 'No document'}
                            </div>
                        </div>
                        <ExternalLink size={16} style={{ opacity: 0.4, marginTop: 4, flexShrink: 0 }} />
                    </div>

                    <div className="editor-preview">
                        {activeDoc
                            ? <div dangerouslySetInnerHTML={{ __html: activeDoc.content.substring(0, 400) }} />
                            : <p style={{ color: 'rgba(255,255,255,0.25)' }}>No active document</p>
                        }
                    </div>

                    <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                        {/* Switch active doc */}
                        <select
                            className="cf-select"
                            style={{ flex: 1, marginBottom: 0 }}
                            value={activeDocId}
                            onChange={e => setActiveDoc(e.target.value)}
                        >
                            {docs.map(d => (
                                <option key={d.id} value={d.id}>{d.title}</option>
                            ))}
                        </select>
                        <button
                            id="open-editor-btn"
                            className="neon-btn"
                            onClick={() => navigate(`/editor/${activeDoc?.id}`)}
                            style={{ flexShrink: 0 }}
                        >
                            Open Editor
                        </button>
                    </div>
                </div>

                {/* ─── Col 4: Stats ─── */}
                <div className="module-box" style={{ gridColumn: 'span 2' }}>
                    <span className="label-text" style={{ color: 'var(--green)' }}>Workspace Stats</span>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 16 }}>
                        <div style={{ padding: '16px', background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)', borderRadius: 16 }}>
                            <div style={{ fontSize: '0.7rem', color: 'var(--green)', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>Total Edits</div>
                            <div style={{ fontSize: '2.2rem', fontWeight: 800, letterSpacing: '-0.05em', color: 'var(--green)' }}>{stats.totalEdits}</div>
                        </div>
                        <div style={{ padding: '16px', background: 'rgba(168,85,247,0.06)', border: '1px solid rgba(168,85,247,0.15)', borderRadius: 16 }}>
                            <div style={{ fontSize: '0.7rem', color: 'var(--purple)', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>Efficiency</div>
                            <div style={{ fontSize: '2.2rem', fontWeight: 800, letterSpacing: '-0.05em' }}>{stats.efficiency}%</div>
                        </div>
                        <div style={{ padding: '16px', background: 'rgba(34,211,238,0.06)', border: '1px solid rgba(34,211,238,0.15)', borderRadius: 16 }}>
                            <div style={{ fontSize: '0.7rem', color: 'var(--blue)', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>Active Time</div>
                            <div style={{ fontSize: '1.6rem', fontWeight: 800, letterSpacing: '-0.04em' }}>{stats.activeTime}</div>
                        </div>
                        <div style={{ padding: '16px', background: 'rgba(236,72,153,0.06)', border: '1px solid rgba(236,72,153,0.15)', borderRadius: 16 }}>
                            <div style={{ fontSize: '0.7rem', color: 'var(--pink)', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>Documents</div>
                            <div style={{ fontSize: '2.2rem', fontWeight: 800, letterSpacing: '-0.05em', color: 'var(--pink)' }}>{stats.docsCreated}</div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}