import { useDocStore } from '../../store/useDocStore';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, Clock, FileText, Users, Zap } from 'lucide-react';

const CATEGORY_COLORS = {
    Academic: '#ec4899',
    Design:   '#22d3ee',
    Planning: '#a855f7',
    Research: '#10b981',
    General:  '#f59e0b',
};

export default function AnalyticsPage() {
    const navigate = useNavigate();
    const { stats, members, docs } = useDocStore();

    // Compute per-member contribution (simulated from role weights)
    const memberContribs = members.map((m, i) => ({
        ...m,
        edits: m.role === 'Owner'  ? Math.round(stats.totalEdits * 0.45) :
               m.role === 'Editor' ? Math.round(stats.totalEdits * 0.25 - i * 4) :
                                     Math.round(stats.totalEdits * 0.05),
    }));
    const maxEdits = Math.max(...memberContribs.map(m => m.edits), 1);

    return (
        <div style={{ maxWidth: 1100, margin: '0 auto' }}>
            {/* Header */}
            <div style={{ marginBottom: 36 }}>
                <span className="label-text">Insights</span>
                <h1 className="hero-text" style={{ fontSize: '2.6rem', marginBottom: 6 }}>Workspace Analytics</h1>
                <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.88rem' }}>
                    Real-time stats synced from the editor
                </p>
            </div>

            <div className="bento-grid" style={{ padding: 0 }}>
                {/* ── Key Metrics Row ── */}
                <div className="module-box" style={{ gridColumn: 'span 1' }}>
                    <span className="label-text" style={{ color: 'var(--green)' }}>Total Edits</span>
                    <div className="stat-number" style={{ color: 'var(--green)', marginTop: 10 }}>{stats.totalEdits}</div>
                    <div className="progress-bar-track">
                        <div className="progress-bar-fill" style={{
                            width: `${Math.min(stats.totalEdits / 3, 100)}%`,
                            background: 'var(--green)',
                            boxShadow: '0 0 12px var(--green)',
                        }} />
                    </div>
                    <p style={{ marginTop: 10, fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)' }}>↑ 12% from last week</p>
                </div>

                <div className="module-box" style={{ gridColumn: 'span 1' }}>
                    <span className="label-text" style={{ color: 'var(--purple)' }}>Sync Efficiency</span>
                    <div className="stat-number" style={{ marginTop: 10 }}>
                        {stats.efficiency}
                        <span style={{ fontSize: '1.4rem', opacity: 0.45 }}>%</span>
                    </div>
                    <div className="progress-bar-track">
                        <div className="progress-bar-fill" style={{
                            width: `${stats.efficiency}%`,
                            background: 'linear-gradient(90deg, var(--purple), var(--blue))',
                            boxShadow: '0 0 12px rgba(168,85,247,0.5)',
                        }} />
                    </div>
                    <p style={{ marginTop: 10, fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)' }}>Excellent performance</p>
                </div>

                <div className="module-box" style={{ gridColumn: 'span 1' }}>
                    <span className="label-text" style={{ color: 'var(--blue)' }}>Active Time</span>
                    <div className="stat-number" style={{ marginTop: 10, fontSize: '2rem' }}>{stats.activeTime}</div>
                    <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
                        <Clock size={14} style={{ color: 'var(--blue)' }} />
                        <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)' }}>This session</span>
                    </div>
                </div>

                <div className="module-box" style={{ gridColumn: 'span 1' }}>
                    <span className="label-text" style={{ color: 'var(--pink)' }}>Documents</span>
                    <div className="stat-number" style={{ color: 'var(--pink)', marginTop: 10 }}>{stats.docsCreated}</div>
                    <div style={{ marginTop: 16, display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }} onClick={() => navigate('/documents')}>
                        <FileText size={14} style={{ color: 'var(--pink)' }} />
                        <span style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)' }}>View all →</span>
                    </div>
                </div>

                {/* ── Member Contributions ── */}
                <div className="module-box" style={{ gridColumn: 'span 2' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                        <span className="label-text" style={{ marginBottom: 0 }}>Member Contributions</span>
                        <Users size={16} style={{ color: 'rgba(255,255,255,0.3)' }} />
                    </div>

                    {memberContribs.map((m) => (
                        <div key={m.id} className="analytics-bar-row">
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: 120, flexShrink: 0 }}>
                                <div style={{
                                    width: 28, height: 28, borderRadius: 8,
                                    background: m.color, display: 'flex',
                                    alignItems: 'center', justifyContent: 'center',
                                    fontWeight: 900, fontSize: '0.72rem', color: '#000',
                                    flexShrink: 0,
                                }}>
                                    {m.role[0]}
                                </div>
                                <span className="analytics-bar-label" style={{ width: 'auto' }}>{m.name}</span>
                            </div>
                            <div className="analytics-bar-track">
                                <div className="analytics-bar-fill" style={{
                                    width: `${(m.edits / maxEdits) * 100}%`,
                                    background: m.color,
                                    boxShadow: `0 0 8px ${m.color}80`,
                                }} />
                            </div>
                            <span className="analytics-bar-value" style={{ color: m.color }}>{m.edits}</span>
                        </div>
                    ))}
                </div>

                {/* ── Document Activity ── */}
                <div className="module-box" style={{ gridColumn: 'span 2' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                        <span className="label-text" style={{ marginBottom: 0 }}>Document Activity</span>
                        <TrendingUp size={16} style={{ color: 'rgba(255,255,255,0.3)' }} />
                    </div>

                    {docs.map((doc) => {
                        const catColor = CATEGORY_COLORS[doc.category] ?? '#fff';
                        const fillPct  = doc.content.length > 400 ? 90 : doc.content.length > 200 ? 60 : doc.content.length > 100 ? 35 : 15;
                        return (
                            <div key={doc.id} className="analytics-bar-row"
                                 style={{ cursor: 'pointer' }}
                                 onClick={() => navigate(`/editor/${doc.id}`)}
                            >
                                <span className="analytics-bar-label" style={{
                                    width: 160, overflow: 'hidden', textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap', color: 'rgba(255,255,255,0.7)',
                                }}>
                                    {doc.title}
                                </span>
                                <div className="analytics-bar-track">
                                    <div className="analytics-bar-fill" style={{
                                        width: `${fillPct}%`,
                                        background: catColor,
                                        boxShadow: `0 0 8px ${catColor}60`,
                                    }} />
                                </div>
                                <span className="analytics-bar-value" style={{ color: catColor, fontSize: '0.7rem' }}>
                                    {doc.lastEdited}
                                </span>
                            </div>
                        );
                    })}
                </div>

                {/* ── Team Health ── */}
                <div className="module-box" style={{ gridColumn: 'span 4', display: 'flex', alignItems: 'center', gap: 24 }}>
                    <div style={{
                        width: 56, height: 56, borderRadius: 16,
                        background: 'rgba(16,185,129,0.12)',
                        border: '1px solid rgba(16,185,129,0.25)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        flexShrink: 0,
                    }}>
                        <Zap size={24} style={{ color: 'var(--green)' }} />
                    </div>
                    <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 800, fontSize: '1.1rem', marginBottom: 4 }}>
                            Team Health: <span style={{ color: 'var(--green)' }}>Excellent</span>
                        </div>
                        <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.85rem' }}>
                            {members.filter(m => m.status === 'Online').length} of {members.length} members online. {stats.efficiency}% sync efficiency. All systems nominal.
                        </p>
                    </div>
                    <div style={{ textAlign: 'right', flexShrink: 0 }}>
                        <div style={{ fontSize: '2rem', fontWeight: 800, letterSpacing: '-0.05em', color: 'var(--green)' }}>
                            {stats.efficiency}%
                        </div>
                        <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.35)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                            Uptime
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}