import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/useAuthStore';
import { useDocStore } from '../../store/useDocStore';

const ROLES = ['Owner', 'Editor', 'Viewer'];

const ROLE_META = {
    Owner:  { color: '#ec4899', desc: 'Full access' },
    Editor: { color: '#22d3ee', desc: 'Create & edit' },
    Viewer: { color: '#10b981', desc: 'Read only' },
};

export default function Login() {
    const navigate  = useNavigate();
    const login     = useAuthStore((s) => s.login);
    const setRole   = useDocStore((s) => s.setCurrentUserRole);

    const [name,     setName]     = useState('Arisha');
    const [email,    setEmail]    = useState('');
    const [role,     setRoleSt]   = useState('Owner');

    const handleLogin = () => {
        if (!name.trim()) return;
        login({ id: Date.now(), name: name.trim(), email, role, avatar: `https://i.pravatar.cc/128?u=${name}` });
        setRole(role);
        navigate('/');
    };

    return (
        <div className="login-page">
            <div className="login-card">
                <div className="login-logo">CollabFlow</div>
                <p className="login-subtitle">Your real-time collaborative workspace</p>

                <input
                    id="login-name"
                    className="cf-input"
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <input
                    id="login-email"
                    className="cf-input"
                    type="email"
                    placeholder="Email (optional)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />

                <div style={{ marginBottom: 8 }}>
                    <span className="label-text" style={{ marginBottom: 10 }}>Join as</span>
                    <div className="role-selector">
                        {ROLES.map((r) => {
                            const meta = ROLE_META[r];
                            return (
                                <button
                                    key={r}
                                    id={`role-${r.toLowerCase()}`}
                                    className={`role-option${role === r ? ' selected' : ''}`}
                                    onClick={() => setRoleSt(r)}
                                    style={role === r ? { borderColor: meta.color, background: `${meta.color}18` } : {}}
                                >
                                    <span
                                        className="role-badge-small"
                                        style={{ background: meta.color }}
                                    >
                                        {r[0]}
                                    </span>
                                    <span style={{ display: 'block', fontWeight: 700, color: role === r ? '#fff' : undefined }}>{r}</span>
                                    <span style={{ display: 'block', fontSize: '0.65rem', opacity: 0.6, marginTop: 2 }}>{meta.desc}</span>
                                </button>
                            );
                        })}
                    </div>
                </div>

                <button
                    id="login-btn"
                    className="neon-btn"
                    onClick={handleLogin}
                    style={{ width: '100%', marginTop: 12 }}
                >
                    Enter Workspace →
                </button>
                <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.25)', fontSize: '0.78rem', marginTop: 20 }}>
                    Demo mode — no backend required
                </p>
            </div>
        </div>
    );
}