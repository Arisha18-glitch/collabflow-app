import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDocStore } from '../../store/useDocStore';
import { Plus, X, Zap, Clock, FileText, Users } from 'lucide-react';

export default function Dashboard() {
    const navigate = useNavigate();
    const { docs, members, stats, addDocument, setActiveDoc } = useDocStore();

    const [showModal, setShowModal] = useState(false);
    const [newTitle, setNewTitle]   = useState('');

    const handleCreate = () => {
        const t = newTitle.trim();
        if (!t) return;
        addDocument(t);
        setNewTitle('');
        setShowModal(false);
        navigate('/documents');
    };

    const handleOpenDoc = (doc) => {
        setActiveDoc(doc.id);
        navigate(`/editor/${doc.id}`);
    };

    return (
        <>
            {/* ── Create Document Modal ── */}
            {showModal && (
                <div className="modal-overlay" onClick={() => setShowModal(false)}>
                    <div className="modal-box" onClick={(e) => e.stopPropagation()}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
                            <div className="modal-title">New Document</div>
                            <button className="icon-btn" onClick={() => setShowModal(false)}>
                                <X size={18} />
                            </button>
                        </div>
                        <input
                            id="new-doc-title"
                            className="cf-input"
                            placeholder="Document title..."
                            value={newTitle}
                            onChange={(e) => setNewTitle(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                            autoFocus
                        />
                        <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
                            <button className="ghost-btn" onClick={() => setShowModal(false)} style={{ flex: 1 }}>
                                Cancel
                            </button>
                            <button className="neon-btn" onClick={handleCreate} style={{ flex: 1 }}>
                                Create
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <div className="bento-grid">
                {/* ── Hero Card ── */}
                <div className="module-box" style={{ gridColumn: 'span 3', minHeight: 280, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    <span className="label-text">Overview</span>
                    <h1 className="hero-text" style={{ marginBottom: 12 }}>
                        Design. Sync.{' '}
                        <span style={{ color: 'var(--blue)', WebkitTextFillColor: 'var(--blue)' }}>
                            Collaborate.
                        </span>
                    </h1>
                    <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '1rem', maxWidth: 440, lineHeight: 1.65, marginBottom: 28 }}>
                        Real-time collaborative workspace for your projects, designs, and async workflows — all in one place.
                    </p>
                    <button
                        id="quick-create-btn"
                        className="neon-btn glow-pink"
                        onClick={() => setShowModal(true)}
                        style={{ width: 'fit-content', display: 'flex', alignItems: 'center', gap: 8 }}
                    >
                        <Plus size={16} />
                        Quick Create
                    </button>
                </div>

                {/* ── Active Members ── */}
                <div className="module-box" style={{ gridRow: 'span 2' }}>
                    <span className="label-text" style={{ color: 'var(--blue)' }}>Active Now</span>
                    <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column', gap: 10 }}>
                        {members.map((m) => (
                            <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                                <div style={{
                                    width: 38, height: 38, borderRadius: 12,
                                    background: m.color, display: 'flex',
                                    alignItems: 'center', justifyContent: 'center',
                                    fontWeight: 900, fontSize: '0.85rem', color: '#000',
                                    flexShrink: 0,
                                    opacity: m.status === 'Offline' ? 0.4 : 1,
                                }}>
                                    {m.name[0]}
                                </div>
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <div style={{ fontWeight: 700, fontSize: '0.85rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.name}</div>
                                    <div style={{ fontSize: '0.7rem', color: m.status === 'Online' ? 'var(--green)' : m.status === 'Idle' ? 'var(--blue)' : 'rgba(255,255,255,0.25)' }}>
                                        ● {m.status}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* ── Stats Row ── */}
                <div className="module-box" style={{ gridColumn: 'span 1' }}>
                    <span className="label-text" style={{ color: 'var(--green)' }}>Total Edits</span>
                    <div className="stat-number" style={{ color: 'var(--green)', marginTop: 10 }}>{stats.totalEdits}</div>
                    <div className="progress-bar-track" style={{ marginTop: 14 }}>
                        <div className="progress-bar-fill" style={{ width: '82%', background: 'var(--green)', boxShadow: '0 0 10px var(--green)' }} />
                    </div>
                    <p style={{ margin: '10px 0 0', fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)' }}>↑ 12% from last week</p>
                </div>

                <div className="module-box" style={{ gridColumn: 'span 1' }}>
                    <span className="label-text" style={{ color: 'var(--purple)' }}>Efficiency</span>
                    <div className="stat-number" style={{ marginTop: 10 }}>{stats.efficiency}<span style={{ fontSize: '1.2rem', opacity: 0.5 }}>%</span></div>
                    <div className="progress-bar-track" style={{ marginTop: 14 }}>
                        <div className="progress-bar-fill" style={{ width: `${stats.efficiency}%`, background: 'var(--purple)', boxShadow: '0 0 10px var(--purple)' }} />
                    </div>
                </div>

                <div className="module-box" style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ width: 46, height: 46, borderRadius: 14, background: 'rgba(34,211,238,0.12)', border: '1px solid rgba(34,211,238,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Clock size={20} style={{ color: 'var(--blue)' }} />
                    </div>
                    <div>
                        <span className="label-text" style={{ color: 'var(--blue)', marginBottom: 2 }}>Active Time</span>
                        <div style={{ fontWeight: 800, fontSize: '1.3rem', letterSpacing: '-0.04em' }}>{stats.activeTime}</div>
                    </div>
                </div>

                <div className="module-box" style={{ display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer' }} onClick={() => navigate('/workspace')}>
                    <div style={{ width: 46, height: 46, borderRadius: 14, background: 'rgba(236,72,153,0.12)', border: '1px solid rgba(236,72,153,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Users size={20} style={{ color: 'var(--pink)' }} />
                    </div>
                    <div>
                        <span className="label-text" style={{ marginBottom: 2 }}>Members</span>
                        <div style={{ fontWeight: 800, fontSize: '1.3rem', letterSpacing: '-0.04em' }}>{stats.membersCount}</div>
                    </div>
                </div>

                {/* ── Recent Documents ── */}
                <div className="module-box" style={{ gridColumn: 'span 4' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
                        <span className="label-text" style={{ marginBottom: 0 }}>Recent Documents</span>
                        <button className="ghost-btn" onClick={() => navigate('/documents')} style={{ fontSize: '0.75rem', padding: '6px 14px' }}>
                            View All →
                        </button>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
                        {docs.slice(0, 4).map((doc) => (
                            <div
                                key={doc.id}
                                onClick={() => handleOpenDoc(doc)}
                                style={{
                                    padding: '16px 18px',
                                    background: 'rgba(255,255,255,0.025)',
                                    border: '1px solid var(--border)',
                                    borderRadius: 18,
                                    cursor: 'pointer',
                                    transition: 'all 0.2s ease',
                                }}
                                onMouseEnter={(e) => {
                                    e.currentTarget.style.background = 'rgba(255,255,255,0.06)';
                                    e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)';
                                }}
                                onMouseLeave={(e) => {
                                    e.currentTarget.style.background = 'rgba(255,255,255,0.025)';
                                    e.currentTarget.style.borderColor = 'var(--border)';
                                }}
                            >
                                <div style={{ color: 'var(--pink)', marginBottom: 10 }}>
                                    <FileText size={20} />
                                </div>
                                <div style={{ fontWeight: 700, fontSize: '0.9rem', marginBottom: 4, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                    {doc.title}
                                </div>
                                <div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.35)' }}>
                                    {doc.category} · {doc.lastEdited}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
}