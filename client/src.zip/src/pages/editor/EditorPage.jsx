import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { useDocStore } from '../../store/useDocStore';
import {
    Bold, Italic, Strikethrough, Code2, List, ListOrdered,
    Heading1, Heading2, Undo, Redo, ArrowLeft, Quote
} from 'lucide-react';

function ToolbarButton({ onClick, isActive, title, children, disabled }) {
    return (
        <button
            className={`toolbar-btn${isActive ? ' is-active' : ''}`}
            onClick={onClick}
            title={title}
            disabled={disabled}
        >
            {children}
        </button>
    );
}

export default function EditorPage() {
    const { docId }   = useParams();
    const navigate    = useNavigate();
    const { docs, updateDocument, setActiveDoc, currentUserRole, stats } = useDocStore();

    const doc = docs.find(d => d.id === docId) ?? docs[0];
    const isReadOnly = currentUserRole === 'Viewer';

    const editor = useEditor({
        extensions: [
            StarterKit,
            Placeholder.configure({ placeholder: 'Start writing something amazing…' }),
        ],
        content:  doc?.content ?? '',
        editable: !isReadOnly,
        onUpdate: ({ editor }) => {
            if (!isReadOnly && doc) {
                updateDocument(doc.id, editor.getHTML());
            }
        },
    });

    // Sync when navigating to a different doc
    useEffect(() => {
        if (editor && doc && editor.getHTML() !== doc.content) {
            editor.commands.setContent(doc.content, false);
        }
        if (doc) setActiveDoc(doc.id);
    }, [docId]); // eslint-disable-line

    // Update editable flag when role changes
    useEffect(() => {
        if (editor) {
            editor.setEditable(!isReadOnly);
        }
    }, [isReadOnly, editor]);

    if (!doc) {
        return (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
                <div style={{ textAlign: 'center' }}>
                    <p style={{ color: 'rgba(255,255,255,0.4)', marginBottom: 16 }}>Document not found.</p>
                    <button className="ghost-btn" onClick={() => navigate('/documents')}>← Back to Documents</button>
                </div>
            </div>
        );
    }

    return (
        <div className="editor-page">
            {/* Back bar */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
                <button
                    id="editor-back-btn"
                    className="ghost-btn"
                    onClick={() => navigate('/documents')}
                    style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                >
                    <ArrowLeft size={14} /> Documents
                </button>
                <span style={{ color: 'rgba(255,255,255,0.2)' }}>/</span>
                <span style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.5)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 260 }}>
                    {doc.title}
                </span>
            </div>

            <div className="editor-container">
                {/* Header */}
                <div className="editor-header">
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <div className="editor-title" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {doc.title}
                        </div>
                        <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)', marginTop: 4 }}>
                            Last edited {doc.lastEdited} · {stats.totalEdits} total edits
                        </div>
                    </div>
                    <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexShrink: 0 }}>
                        {isReadOnly ? (
                            <span className="readonly-badge">Read Only</span>
                        ) : (
                            <span className="status-badge">
                                <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)', display: 'inline-block', animation: 'pulse-dot 2s infinite' }} />
                                Live Sync
                            </span>
                        )}
                        <span style={{
                            padding: '5px 12px',
                            borderRadius: 100,
                            fontSize: '0.72rem',
                            fontWeight: 700,
                            background: 'rgba(255,255,255,0.05)',
                            color: 'rgba(255,255,255,0.5)',
                            border: '1px solid var(--border)',
                        }}>
                            {currentUserRole}
                        </span>
                    </div>
                </div>

                {/* Toolbar */}
                {!isReadOnly && editor && (
                    <div className="editor-toolbar">
                        <ToolbarButton onClick={() => editor.chain().focus().undo().run()} title="Undo">
                            <Undo size={15} />
                        </ToolbarButton>
                        <ToolbarButton onClick={() => editor.chain().focus().redo().run()} title="Redo">
                            <Redo size={15} />
                        </ToolbarButton>

                        <div className="toolbar-divider" />

                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
                            isActive={editor.isActive('heading', { level: 1 })}
                            title="Heading 1"
                        >
                            <Heading1 size={15} />
                        </ToolbarButton>
                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
                            isActive={editor.isActive('heading', { level: 2 })}
                            title="Heading 2"
                        >
                            <Heading2 size={15} />
                        </ToolbarButton>

                        <div className="toolbar-divider" />

                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleBold().run()}
                            isActive={editor.isActive('bold')}
                            title="Bold"
                        >
                            <Bold size={15} />
                        </ToolbarButton>
                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleItalic().run()}
                            isActive={editor.isActive('italic')}
                            title="Italic"
                        >
                            <Italic size={15} />
                        </ToolbarButton>
                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleStrike().run()}
                            isActive={editor.isActive('strike')}
                            title="Strikethrough"
                        >
                            <Strikethrough size={15} />
                        </ToolbarButton>

                        <div className="toolbar-divider" />

                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleBulletList().run()}
                            isActive={editor.isActive('bulletList')}
                            title="Bullet List"
                        >
                            <List size={15} />
                        </ToolbarButton>
                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleOrderedList().run()}
                            isActive={editor.isActive('orderedList')}
                            title="Ordered List"
                        >
                            <ListOrdered size={15} />
                        </ToolbarButton>
                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleBlockquote().run()}
                            isActive={editor.isActive('blockquote')}
                            title="Blockquote"
                        >
                            <Quote size={15} />
                        </ToolbarButton>

                        <div className="toolbar-divider" />

                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleCode().run()}
                            isActive={editor.isActive('code')}
                            title="Inline Code"
                        >
                            <Code2 size={15} />
                        </ToolbarButton>
                        <ToolbarButton
                            onClick={() => editor.chain().focus().toggleCodeBlock().run()}
                            isActive={editor.isActive('codeBlock')}
                            title="Code Block"
                        >
                            <span style={{ fontSize: '0.72rem', fontFamily: 'monospace' }}>{'{ }'}</span>
                        </ToolbarButton>
                    </div>
                )}

                {/* Editor Content */}
                <EditorContent
                    editor={editor}
                    className={`prose-area${isReadOnly ? ' readonly' : ''}`}
                />
            </div>
        </div>
    );
}