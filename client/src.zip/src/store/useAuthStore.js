import { create } from 'zustand';

export const useAuthStore = create((set) => ({
    user: null,
    isAuthenticated: false,
    currentWorkspace: { name: 'Team Collab' },

    login: (userData) => set({
        user: userData,
        isAuthenticated: true,
    }),

    logout: () => set({ user: null, isAuthenticated: false }),

    setWorkspace: (ws) => set({ currentWorkspace: ws }),
}));