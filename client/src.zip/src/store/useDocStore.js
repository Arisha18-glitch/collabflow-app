import { create } from 'zustand';

const VALID_ROLES = ['Owner', 'Editor', 'Viewer'];

const ROLE_PERMISSIONS = {
    Owner:  ['create', 'edit', 'delete', 'invite'],
    Editor: ['create', 'edit'],
    Viewer: ['view'],
};

const ROLE_COLORS = {
    Owner:  '#ec4899',
    Editor: '#22d3ee',
    Viewer: '#10b981',
};

export const useDocStore = create((set, get) => ({
    // ─── State ────────────────────────────────────────
    activeDocId: '1',
    currentUserRole: 'Owner',

    docs: [
        {
            id: '1',
            title: 'Semester Project Proposal',
            content: '<h2>Initial Draft</h2><p>This document outlines the key milestones for our collaborative semester project. We will be building a real-time workspace tool inspired by modern design aesthetics.</p>',
            lastEdited: '2m ago',
            category: 'Academic',
        },
        {
            id: '2',
            title: 'UI Design System v2',
            content: '<h2>Design Tokens</h2><p>Color palette, typography scale, spacing system and component library guidelines for the Vibe-Sync product family.</p>',
            lastEdited: '1h ago',
            category: 'Design',
        },
        {
            id: '3',
            title: 'Sprint Planning — Week 12',
            content: '<h2>Sprint Goals</h2><ul><li>Complete the Tiptap editor integration</li><li>Wire Zustand state to all modules</li><li>Deploy to Vercel staging</li></ul>',
            lastEdited: '3h ago',
            category: 'Planning',
        },
        {
            id: '4',
            title: 'Research Notes — Peer Review',
            content: '<h2>Literature Review</h2><p>Notes from 5 peer-reviewed papers on real-time collaboration tools and their impact on team productivity.</p>',
            lastEdited: 'Yesterday',
            category: 'Research',
        },
    ],

    members: [
        { id: 'm1', name: 'Arisha',  role: 'Owner',  color: '#ec4899', status: 'Online',  permissions: ROLE_PERMISSIONS.Owner },
        { id: 'm2', name: 'Ahmed',   role: 'Editor', color: '#22d3ee', status: 'Online',  permissions: ROLE_PERMISSIONS.Editor },
        { id: 'm3', name: 'Sara',    role: 'Editor', color: '#22d3ee', status: 'Idle',    permissions: ROLE_PERMISSIONS.Editor },
        { id: 'm4', name: 'Zara',    role: 'Viewer', color: '#10b981', status: 'Offline', permissions: ROLE_PERMISSIONS.Viewer },
    ],

    stats: {
        totalEdits:  184,
        efficiency:  98.2,
        activeTime:  '14h 22m',
        docsCreated: 4,
        membersCount: 4,
    },

    // ─── Actions ──────────────────────────────────────

    setActiveDoc: (id) => set({ activeDocId: id }),

    setCurrentUserRole: (role) => {
        if (!VALID_ROLES.includes(role)) return;
        set({ currentUserRole: role });
    },

    addDocument: (title) => set((state) => {
        const newDoc = {
            id: Date.now().toString(),
            title,
            content: `<h2>${title}</h2><p>Start writing here...</p>`,
            lastEdited: 'Just now',
            category: 'General',
        };
        return {
            docs: [newDoc, ...state.docs],
            activeDocId: newDoc.id,
            stats: {
                ...state.stats,
                totalEdits:  state.stats.totalEdits + 1,
                docsCreated: state.stats.docsCreated + 1,
            },
        };
    }),

    updateDocument: (id, newContent) => set((state) => ({
        docs: state.docs.map(d =>
            d.id === id
                ? { ...d, content: newContent, lastEdited: 'Just now' }
                : d
        ),
        stats: { ...state.stats, totalEdits: state.stats.totalEdits + 1 },
    })),

    deleteDocument: (id) => set((state) => {
        const remaining = state.docs.filter(d => d.id !== id);
        return {
            docs: remaining,
            activeDocId: state.activeDocId === id
                ? (remaining[0]?.id ?? null)
                : state.activeDocId,
            stats: {
                ...state.stats,
                docsCreated: Math.max(0, state.stats.docsCreated - 1),
            },
        };
    }),

    addMember: (name, role) => {
        if (!VALID_ROLES.includes(role)) {
            console.warn(`Invalid role: "${role}". Must be one of ${VALID_ROLES.join(', ')}.`);
            return;
        }
        set((state) => ({
            members: [
                ...state.members,
                {
                    id:          `m${Date.now()}`,
                    name:        name.trim(),
                    role,
                    color:       ROLE_COLORS[role],
                    status:      'Online',
                    permissions: ROLE_PERMISSIONS[role],
                },
            ],
            stats: { ...state.stats, membersCount: state.stats.membersCount + 1 },
        }));
    },

    removeMember: (id) => set((state) => ({
        members: state.members.filter(m => m.id !== id),
        stats: { ...state.stats, membersCount: Math.max(0, state.stats.membersCount - 1) },
    })),

    updateStats: (newStats) => set((state) => ({
        stats: { ...state.stats, ...newStats },
    })),

    // ─── Selectors (helpers) ──────────────────────────
    getActiveDoc: () => {
        const { docs, activeDocId } = get();
        return docs.find(d => d.id === activeDocId) ?? docs[0];
    },
}));